package de.laliluna.library.struts;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;

public class CustomAction extends Action {
	protected Logger log = Logger.getLogger(this.getClass());
}
